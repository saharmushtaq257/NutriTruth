# 🥗 Nutrition Myth Buster

Nutrition Myth Buster is an AI-powered Streamlit web application that helps users evaluate common food and dietary claims. Powered by the high-speed **Groq API**, the app classifies nutrition claims as **FACT**, **MYTH**, or **PARTIALLY TRUE**, giving clear, beginner-friendly scientific explanations.

---

## ✨ Features
- 🥗 **Instant Myth Evaluation**: Analyzes any nutrition claim in seconds.
- 🎯 **Structured Verdicts**: Displays clear badges (✅ FACT, ❌ MYTH, ⚠️ PARTIALLY TRUE).
- 📌 **Clickable Example Claims**: Quick-select common nutrition myths from the sidebar.
- 📜 **Session History**: Easily review claims checked during your current session.
- 🔒 **Secure API Management**: Configured safely using Streamlit Secrets.
- ⚠️ **Health Disclaimer**: Built-in responsible disclaimers regarding professional medical advice.

---

## 🛠️ Technologies Used
- **Python 3.9+**
- **Streamlit**: Web framework for simple, beautiful UIs.
- **Groq Python SDK**: Ultra-fast AI inference engine.
- **LLM Model**: `llama-3.3-70b-versatile`

---

## 📁 Project Structure
```text
nutrition-myth-buster/
│
├── app.py                  # Main Streamlit application
├── requirements.txt        # Required dependencies
├── README.md               # Project documentation
├── .gitignore              # Files ignored by Git
└── .streamlit/
    └── secrets.toml.example# Example configuration for secrets
```

---

## 🚀 Local Installation & Setup

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/nutrition-myth-buster.git
cd nutrition-myth-buster
```

### 2. Create and activate a virtual environment
- **macOS/Linux**:
  ```bash
  python3 -m venv venv
  source venv/bin/activate
  ```
- **Windows**:
  ```cmd
  python -m venv venv
  venv\Scripts\activate
  ```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set up your Groq API Key
1. Get a free API key from the [Groq Console](https://console.groq.com/).
2. Create a `.streamlit` folder in the root directory:
   ```bash
   mkdir .streamlit
   ```
3. Create a `secrets.toml` file inside `.streamlit/`:
   ```toml
   GROQ_API_KEY = "gsk_your_actual_api_key_here"
   ```

### 5. Run the app
```bash
streamlit run app.py
```

---

## ☁️ Deploying on Streamlit Community Cloud

1. Push your code to a public or private GitHub repository.
2. Visit [share.streamlit.io](https://share.streamlit.io/) and log in.
3. Click **New app**, select your repository, branch (`main`), and set the main file path to `app.py`.
4. Click **Advanced settings...** -> **Secrets**.
5. Add your Groq API key in the secrets editor:
   ```toml
   GROQ_API_KEY = "gsk_your_actual_api_key_here"
   ```
6. Click **Save** and **Deploy**!

---

## 🔮 Future Improvements
- 📊 Add citations or web search links for verified research papers.
- 🔊 Add text-to-speech for audio myth breakdowns.
- 🌐 Multi-language support for international health awareness.
