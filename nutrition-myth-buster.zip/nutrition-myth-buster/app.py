import json
import streamlit as st
from groq import Groq

# ==========================================
# CONSTANTS & CONFIGURATION
# ==========================================
# Easy to change model in one place
GROQ_MODEL = "llama-3.3-70b-versatile"

# Page Configuration
st.set_page_config(
    page_title="Nutrition Myth Buster",
    page_icon="🥗",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Example Claims for quick interaction
EXAMPLE_MYTHS = [
    "Carbs make you fat",
    "Eating after 8 PM always causes weight gain",
    "Detox drinks remove toxins from the body",
    "Breakfast is the most important meal of the day",
    "Drinking lemon water burns fat",
    "Microwaving food destroys all its nutrients",
    "Gluten is bad for everyone",
]


# ==========================================
# HELPER FUNCTIONS
# ==========================================
def init_session_state():
    """Initialize session state variables for chat history and inputs."""
    if "history" not in st.session_state:
        st.session_state.history = []
    if "user_claim" not in st.session_state:
        st.session_state.user_claim = ""


def get_groq_client():
    """
    Safely initialize and return the Groq client using Streamlit secrets.
    """
    try:
        api_key = st.secrets["GROQ_API_KEY"]
        if not api_key:
            st.error("GROQ_API_KEY found in secrets, but it is empty.")
            return None
        return Groq(api_key=api_key)
    except KeyError:
        st.error(
            "⚠️ GROQ_API_KEY not found in Streamlit Secrets. "
            "Please add it to `.streamlit/secrets.toml` locally or in Streamlit Cloud settings."
        )
        return None
    except Exception as e:
        st.error(f"Error initializing Groq client: {e}")
        return None


def analyze_nutrition_claim(client: Groq, claim: str) -> dict:
    """
    Sends the claim to Groq API and expects a structured JSON response.
    """
    system_prompt = """
    You are an expert, evidence-based nutrition science communicator. 
    Analyze the user's nutrition claim and evaluate it objectively based on current scientific consensus.

    You MUST respond with ONLY a valid JSON object matching this structure:
    {
        "verdict": "FACT" | "MYTH" | "PARTIALLY TRUE",
        "short_explanation": "1-2 simple sentences summarizing why.",
        "scientific_evidence": "A simple breakdown of what scientific consensus and research generally say.",
        "practical_takeaway": "Actionable, simple advice for daily life.",
        "confidence_level": "High" | "Medium" | "Low"
    }

    Guidelines:
    - Keep language accessible to beginners and students.
    - Avoid making medical diagnoses or extreme medical claims.
    - Be objective, respectful, and balanced.
    - Output strict raw JSON without markdown backticks.
    """

    try:
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Analyze this claim: '{claim}'"},
            ],
            temperature=0.2,
            max_tokens=600,
        )

        raw_content = response.choices[0].message.content.strip()
        
        # Clean potential markdown JSON formatting wrappers
        if raw_content.startswith("```json"):
            raw_content = raw_content[7:]
        if raw_content.startswith("```"):
            raw_content = raw_content[3:]
        if raw_content.endswith("```"):
            raw_content = raw_content[:-3]
        
        data = json.loads(raw_content.strip())
        return data

    except json.JSONDecodeError:
        return {
            "verdict": "PARTIALLY TRUE",
            "short_explanation": raw_content if 'raw_content' in locals() else "Could not format response cleanly.",
            "scientific_evidence": "Please refer to the explanation above.",
            "practical_takeaway": "Consult a registered dietitian for individual guidance.",
            "confidence_level": "Medium"
        }
    except Exception as e:
        st.error(f"API Error: {str(e)}")
        return None


def render_verdict_badge(verdict: str):
    """Render color-coded verdict banner."""
    verdict_upper = verdict.upper()
    if "FACT" in verdict_upper and "PARTIALLY" not in verdict_upper:
        st.success("### ✅ VERDICT: FACT")
    elif "MYTH" in verdict_upper:
        st.error("### ❌ VERDICT: MYTH")
    else:
        st.warning("### ⚠️ VERDICT: PARTIALLY TRUE")


# ==========================================
# MAIN APPLICATION
# ==========================================
def main():
    init_session_state()

    # --- SIDEBAR ---
    with st.sidebar:
        st.title("💡 Quick Examples")
        st.write("Click any claim below to load it into the checker:")

        for idx, example in enumerate(EXAMPLE_MYTHS):
            if st.button(f"📌 {example}", key=f"ex_{idx}", use_container_width=True):
                st.session_state.user_claim = example
                st.rerun()

        st.divider()
        st.markdown("### ℹ️ About")
        st.info(
            "This app uses AI powered by **Groq** to evaluate popular nutrition myths "
            "against scientific facts. Always consult a registered dietitian for personalized advice."
        )

    # --- HEADER ---
    st.title("🥗 Nutrition Myth Buster")
    st.markdown(
        "Unsure if a nutrition claim is real science or internet hype? "
        "Enter any claim below to get an instant, evidence-based breakdown!"
    )
    st.divider()

    # --- INPUT SECTION ---
    st.subheader("🔍 Check a Nutrition Claim")

    claim_input = st.text_area(
        label="Enter a food or diet claim:",
        value=st.session_state.user_claim,
        placeholder="e.g., Eating carbs late at night causes instant weight gain...",
        height=100,
    )

    col1, col2 = st.columns([1, 4])
    with col1:
        check_button = st.button("🔎 Check Myth", type="primary", use_container_width=True)
    with col2:
        if st.button("🧹 Clear Input"):
            st.session_state.user_claim = ""
            st.rerun()

    # --- MYTH CHECK LOGIC ---
    if check_button:
        clean_claim = claim_input.strip()

        if not clean_claim:
            st.warning("⚠️ Please enter a claim before clicking Check Myth.")
        else:
            st.session_state.user_claim = clean_claim

            client = get_groq_client()
            if client:
                with st.spinner("🔬 Analyzing scientific evidence via Groq..."):
                    result = analyze_nutrition_claim(client, clean_claim)

                if result:
                    st.divider()
                    render_verdict_badge(result.get("verdict", "UNKNOWN"))

                    col_a, col_b = st.columns(2)
                    with col_a:
                        st.markdown(f"**Confidence Level:** `{result.get('confidence_level', 'N/A')}`")
                    with col_b:
                        st.markdown(f"**Analyzed Claim:** *"{clean_claim}"*")

                    st.markdown("#### 📝 Short Explanation")
                    st.write(result.get("short_explanation", ""))

                    st.markdown("#### 🔬 What the Evidence Says")
                    st.write(result.get("scientific_evidence", ""))

                    st.markdown("#### 💡 Practical Takeaway")
                    st.info(result.get("practical_takeaway", ""))

                    history_item = {
                        "claim": clean_claim,
                        "verdict": result.get("verdict", "UNKNOWN"),
                        "explanation": result.get("short_explanation", ""),
                    }
                    st.session_state.history.insert(0, history_item)

    # --- SESSION HISTORY ---
    if st.session_state.history:
        st.divider()
        st.subheader("📜 Recent Session History")

        for idx, item in enumerate(st.session_state.history):
            badge = "✅ FACT" if "FACT" in item["verdict"] else ("❌ MYTH" if "MYTH" in item["verdict"] else "⚠️ PARTIALLY TRUE")
            with st.expander(f"{badge}: {item['claim']}"):
                st.write(f"**Verdict:** {item['verdict']}")
                st.write(f"**Summary:** {item['explanation']}")

        if st.button("Clear History"):
            st.session_state.history = []
            st.rerun()

    # --- FOOTER & DISCLAIMER ---
    st.divider()
    st.caption(
        "⚠️ **Disclaimer:** This application provides general educational information only "
        "and is powered by AI. It is not a substitute for professional medical advice, diagnosis, "
        "or dietary guidance. Always seek advice from a qualified health provider or registered dietitian."
    )


if __name__ == "__main__":
    main()
